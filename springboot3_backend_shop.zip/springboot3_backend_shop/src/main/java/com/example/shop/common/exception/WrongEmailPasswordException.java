package com.example.shop.common.exception;

public class WrongEmailPasswordException extends RuntimeException{

	public WrongEmailPasswordException() {
		
	}
}
